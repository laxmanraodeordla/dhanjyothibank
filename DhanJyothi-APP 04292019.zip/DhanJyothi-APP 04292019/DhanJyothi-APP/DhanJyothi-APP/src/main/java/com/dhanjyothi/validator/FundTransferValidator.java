package com.dhanjyothi.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.dhanjyothi.model.Transaction;
import com.dhanjyothi.service.AccountService;

@Component
public class FundTransferValidator implements Validator {
	
	@Autowired
	private AccountService accService;

	public boolean supports(Class<?> clazz) {
		return Transaction.class.equals(clazz);
	}

	public void validate(Object target, Errors errors) {
		Transaction trans = (Transaction) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "benificiary.id",
				"beneficiaryEmptyMsg", "Beneficiary is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "transAmt",
				"transAmtEmptyMsg", "Transaction amount is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "remarks",
				"remarksEmptyMsg", "Pls add description");
		
		if(trans.getBenificiary().getId() == 0) {
			errors.rejectValue("benificiary.id",
				"beneficiaryEmptyMsg", "Invalid Beneficiary");
		}
		
		if(trans.getTransAmt() == 0) {
			errors.rejectValue("transAmt",
					"transAmtEmptyMsg", "Transaction Amount is not valid");
		}
		
		if(trans.getRemarks() == null) {
			errors.rejectValue("remarks",
					"remarksEmptyMsg", "Please enter Remarks");
		}
		
		try {
			System.out.println(accService.checkSavingsAccBalance(trans.getTransAmt()));
			if(!accService.checkSavingsAccBalance(trans.getTransAmt())) {
				errors.rejectValue("transAmt", "transAmtBalValue","Insufficient Balance for fund transfer");
			}
		} catch (Exception e) {
			errors.rejectValue("transAmt", "transAmtBalValue","Insufficient Balance for fund transfer");
		}
		
	}

}
