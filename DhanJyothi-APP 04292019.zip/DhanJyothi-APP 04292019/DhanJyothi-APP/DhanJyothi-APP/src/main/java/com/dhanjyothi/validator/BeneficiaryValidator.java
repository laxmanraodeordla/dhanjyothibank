package com.dhanjyothi.validator;

import javax.persistence.Column;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.dhanjyothi.model.Beneficiaries;
import com.dhanjyothi.service.AccountService;

@Component
public class BeneficiaryValidator implements Validator {
	
	@Autowired
	private AccountService accService;

	public boolean supports(Class<?> clazz) {
		return Beneficiaries.class.equals(clazz);
	}

	public void validate(Object target, Errors errors) {
		Beneficiaries ben = (Beneficiaries) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "payeeNickName",
				"NickNameEmptyMsg", "Nick Name is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "payeeName",
				"PayeeNameEmptyMsg", "Payee Name is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "payeeAccNum",
				"PayeeAccNumEmptyMsg", "Acc Num is required");

		if (ben.getPayeeNickName().length() > 100) {
			errors.rejectValue("payeeNickName", "payeeNickNameLength",
					"Max length allowed is 100");
		}
		if (ben.getPayeeName().length() > 100) {
			errors.rejectValue("payeeName", "payeeNameLength",
					"Max length allowed is 100");
		}
		if (ben.getPayeeAccNum() == 0) {
			errors.rejectValue("payeeAccNum", "payeeAccNumMsg",
					"Invalid Acc Num");
		}

		if (ben.getBeneficiaryType().equalsIgnoreCase("External")) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "bankName",
					"BankNameEmptyMsg", "Bank Name is required");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "ifscCode",
					"IfscEmptyMsg", "Ifsc Code is required");
			if (ben.getBankName().length() > 100) {
				errors.rejectValue("bankName", "bankNameMsg",
						"Max length allowed is 100");
			}
			if (ben.getIfscCode() == 0) {
				errors.rejectValue("ifscCode", "ifscCodeMsg",
						"Invalid IFSC Code");
			}
		}
		if (ben.getBeneficiaryType().equalsIgnoreCase("Internal")) {
		try {
			System.out.println(accService.checkAccountExists(ben));
			if(!accService.checkAccountExists(ben)) {
				errors.rejectValue("payeeAccNum", "payeeAccNumMsg","Invalid Acc Num");
			}
		} catch (Exception e) {
			errors.rejectValue("payeeAccNum", "payeeAccNumMsg","Invalid Acc Num");
		}
		}
	}

}
