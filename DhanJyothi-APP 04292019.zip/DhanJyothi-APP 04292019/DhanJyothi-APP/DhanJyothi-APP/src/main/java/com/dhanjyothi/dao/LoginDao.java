package com.dhanjyothi.dao;

import com.dhanjyothi.model.Customer;

public interface LoginDao {
	public boolean validateCustomer(Customer customer);
}
