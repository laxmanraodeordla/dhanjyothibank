package com.dhanjyothi.service;

import java.util.List;

import com.dhanjyothi.model.Customer;



public interface RegisterService {

	public void saveRegister(Customer customer);
	public List<Customer> getAllCustomers();
}
