package com.dhanjyothi.service;

import com.dhanjyothi.model.Customer;



public interface LoginService {
	public boolean validateCustomer(Customer customer);

}
