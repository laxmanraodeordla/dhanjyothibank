package com.dhanjyothi.service;

import java.util.List;
import java.util.Map;

import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Beneficiaries;
import com.dhanjyothi.model.Customer;
import com.dhanjyothi.model.Transaction;

public interface AccountService {

	Customer getCustomerDetails(Customer cust) throws Exception;

	Account getAccountDetails(long custId, String accType) throws Exception;

	void openSavingsAccount(Customer cust) throws Exception;

	void openTermAccount(Account account, Customer custr) throws Exception;

	List<Account> getTermAccountDetails(long custId, String accType)
			throws Exception;

	Map<Integer, String> getTenureDetails();

	boolean checkSavingsAccBalance(long termAmt) throws Exception;

	void updateSavingsAccount(Account account, Customer cust) throws Exception;
	
	void saveBeneficiaries(Account acc,Beneficiaries ben) throws Exception;
	
	boolean checkAccountExists(Beneficiaries ben) throws Exception;
	
	List<Beneficiaries> getAllBeneficiaries(long accId) throws Exception;
	
	void updateFromAccount(Account account,long transAmt,Transaction trans) throws Exception;
	
	void updateToAccount(Transaction trans) throws Exception;
	
	List<Transaction> loadAllTransactions(long accId) throws Exception;
	
	boolean isUserNameExists(String name) throws Exception;
	
	Account checkAccountExists(long accId) throws Exception;
	
	Customer getCustomerById(long custID) throws Exception;
	
	
}
