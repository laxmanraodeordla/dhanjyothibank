package com.dhanjyothi.dao;

import java.util.List;

import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Beneficiaries;
import com.dhanjyothi.model.Customer;
import com.dhanjyothi.model.Transaction;
import com.dhanjyothi.model.User;

public interface AccountDao {
	
	Customer getCustomerDetails(Customer cust) throws Exception;
	
	Account getAccountDetails(long custId, String accType) throws Exception;
	
	void openSavingsAccount(Account acc,boolean isSavingsAccountExists) throws Exception;
	
	void openTermAccount(Account acc) throws Exception;
	
	List<Account> getTermAccountDetails(long custId, String accType) throws Exception;
	
	void saveBeneficiaries(Beneficiaries ben) throws Exception;
	
	Account checkAccountExists(long accId) throws Exception;
	
	List<Beneficiaries> getAllBeneficiaries(long accId) throws Exception;
	
	void updateTransactionDetails(Transaction trans) throws Exception;
	
	List<Transaction> loadAllTransactions(long accId) throws Exception;
	
	Customer isUserNameExists(String name) throws Exception;
	
	Customer getCustomerById(long custID) throws Exception;

}
