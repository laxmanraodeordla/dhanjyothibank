package com.dhanjyothi.controller;

import java.util.List;

import javax.persistence.NoResultException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Customer;
import com.dhanjyothi.model.User;
import com.dhanjyothi.service.AccountService;
import com.dhanjyothi.service.LoginService;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;

	@Autowired
	private AccountService accService;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView showRegister() {
		System.out.println("Hello Login form");
		ModelAndView mav = new ModelAndView();
		mav.addObject("cust", new Customer());
		mav.setViewName("login");
		return mav;
	}

	@RequestMapping(value = "/submit", method = RequestMethod.POST)
	public String validateCustomer(@ModelAttribute("cust") Customer cust,
			HttpServletRequest req, Model model) {
		HttpSession ses = req.getSession();
		Customer custObj = new Customer();
		System.out.println(cust);
		boolean flag = loginService.validateCustomer(cust);
		if (flag == true) {
			try {
				custObj = accService.getCustomerDetails(cust);
				ses.setAttribute("cust", custObj);
				return "redirect:accsummary";
			} catch (NoResultException ne) {
				model.addAttribute("userName",
						custObj.getFirstName().toUpperCase() + " " +custObj.getLastName().toUpperCase());
				model.addAttribute("isAccountExists", false);
				return "redirect:accsummary";
			} catch (Exception e) {
				e.printStackTrace();
				return "error";
			}
		}

		else {
			return "error";
		}
	}

	@RequestMapping("/accsummary")
	public String loadAccSummary(HttpServletRequest req, Model model) {
		HttpSession ses = req.getSession();
		Account acc;
		List<Account> termAcc;
		if (ses != null) {
			Customer cust = (Customer) ses.getAttribute("cust");
			if (cust != null) {
				try {
					acc = accService.getAccountDetails(cust.getId(), "SAVINGS");
					termAcc = accService.getTermAccountDetails(cust.getId(),
							"TERM");
					model.addAttribute("userName",
							cust.getFirstName() + cust.getLastName());
					if (acc != null) {
						ses.setAttribute("account",acc );
						model.addAttribute("isSavingsAccountExists", true);
						model.addAttribute("savingsaccount", acc);
					} else {
						model.addAttribute("isSavingsAccountExists", false);
					}
					if (termAcc.size() > 0) {
						model.addAttribute("isTermAccountExists", true);
						model.addAttribute("termaccount", termAcc);
					} else {
						model.addAttribute("isTermAccountExists", false);
					}
					return "accountsummary";
				} catch (NoResultException ne) {
					model.addAttribute("userName",
							cust.getFirstName().toUpperCase() + " " +cust.getLastName().toUpperCase());
					model.addAttribute("isAccountExists", false);
					return "accountsummary";
				} catch (Exception e) {
					e.printStackTrace();
					return "error";
				}
			} else {
				return "redirect:login";
			}
		} else {
			return "redirect:login";
		}

	}

	@RequestMapping("/adduser")
	public String addUser(HttpServletRequest req, Model model) {
		HttpSession ses = req.getSession();
		Account acc;
		List<Account> termAcc;
		User user = new User();
		user.setName("prabhu");
		User userSes = (User) ses.getAttribute("user");
		try {
			if (userSes != null) {
				acc = accService.getAccountDetails(userSes.getId(), "SAVINGS");
				termAcc = accService.getTermAccountDetails(userSes.getId(),
						"TERM");
				model.addAttribute("userName", userSes.getName());
				System.out.println(termAcc.size());
				if (acc != null) {
					model.addAttribute("isSavingsAccountExists", true);
					model.addAttribute("savingsaccount", acc);
				} else {
					model.addAttribute("isSavingsAccountExists", false);
				}
				if (termAcc.size() > 0) {
					model.addAttribute("isTermAccountExists", true);
					model.addAttribute("termaccount", termAcc);
				} else {
					model.addAttribute("isTermAccountExists", false);
				}
			} else {
				// accService.addUser(user);
				ses.setAttribute("user", user);
				acc = accService.getAccountDetails(user.getId(), "SAVINGS");
				termAcc = accService
						.getTermAccountDetails(user.getId(), "TERM");
				model.addAttribute("userName", user.getName());
				if (acc != null) {
					model.addAttribute("isSavingsAccountExists", true);
					model.addAttribute("savingsaccount", acc);
				} else {
					model.addAttribute("isSavingsAccountExists", false);
				}
				if (termAcc.size() > 0) {
					model.addAttribute("isTermAccountExists", true);
					model.addAttribute("termaccount", termAcc);
				} else {
					model.addAttribute("isTermAccountExists", false);
				}
			}
			System.out.println(acc.getAccBalance() + "-" + acc.getAccId() + "-"
					+ acc.getAccType());
			return "accountsummary";
		} catch (NoResultException ne) {
			model.addAttribute("userName", user.getName());
			model.addAttribute("isAccountExists", false);
			return "accountsummary";
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
	}
	
	@GetMapping("/logout")
	public String logoutPage(HttpServletRequest req) {
		HttpSession ses = req.getSession();
		ses.invalidate();
		return "redirect:login";
	}
}
