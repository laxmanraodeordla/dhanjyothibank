package com.dhanjyothi.service.impl;

import java.util.Base64;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dhanjyothi.dao.AccountDao;
import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Beneficiaries;
import com.dhanjyothi.model.Customer;
import com.dhanjyothi.model.Transaction;
import com.dhanjyothi.model.User;
import com.dhanjyothi.service.AccountService;
import com.dhanjyothi.util.DhanJyothiUtil;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao accountDao;

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private DhanJyothiUtil djUtil;

	public Account getAccountDetails(long custId, String accType)
			throws Exception {
		return accountDao.getAccountDetails(custId, accType);
	}

	public void openSavingsAccount(Customer cust) throws Exception {
		Account acc = new Account();
		acc.setAccType("SAVINGS");
		acc.setAccBalance(10000);
		acc.setCreatedDate(djUtil.getCurrentDate());
		acc.setCust(cust);
		accountDao.openSavingsAccount(acc, false);
	}

	public void openTermAccount(Account account, Customer cust)
			throws Exception {
		account.setAccType("TERM");
		account.setCust(cust);
		account.setCreatedDate(djUtil.getCurrentDate());
		account.setMatureDate(djUtil.getTermMaturityDate(account.getTenure()));
		account.setInterest(djUtil.getInterstDate(account.getTenure(),
				account.getTermAmt()));
		Transaction trans = new Transaction();
		trans.setTransType("Debit");
		trans.setRemarks("Amount Debited for Term Account");
		trans.setTransDate(djUtil.getCurrentDate());
		trans.setTransAmt(account.getTermAmt());
		accountDao.openTermAccount(account);
	}

	public List<Account> getTermAccountDetails(long custId, String accType)
			throws Exception {
		return accountDao.getTermAccountDetails(custId, accType);
	}

	public Map<Integer, String> getTenureDetails() {
		return djUtil.getTenureDetails();
	}

	public boolean checkSavingsAccBalance(long termAmt) throws Exception {
		HttpSession ses = request.getSession();
		Customer cust = (Customer) ses.getAttribute("cust");
		if (cust != null) {
			Account savingsAcc = accountDao.getAccountDetails(cust.getId(),
					"SAVINGS");
			if (savingsAcc != null) {
				if (savingsAcc.getAccBalance() >= termAmt) {
					return true;
				} else {
					return false;
				}

			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public void updateSavingsAccount(Account account, Customer cust)
			throws Exception {
		long savingsAccBalance = 0;
		account.setAccType("SAVINGS");
		account.setCust(cust);
		account.setUpdatedDate(djUtil.getCurrentDate());
		Account savingsAcc = accountDao.getAccountDetails(cust.getId(),
				"SAVINGS");
		if (savingsAcc != null) {
			savingsAccBalance = djUtil.getAccBalance(
					savingsAcc.getAccBalance(), account.getTermAmt());
			account.setAccBalance(savingsAccBalance);
			account.setAccId(savingsAcc.getAccId());
			account.setCreatedDate(savingsAcc.getCreatedDate());
			accountDao.openSavingsAccount(account, true);
			Transaction trans = new Transaction();
			trans.setTransType("Debit");
			trans.setTransDate(djUtil.getCurrentDate());
			trans.setRemarks("Self Transfer Term Account Creation");
			trans.setTransAmt(account.getTermAmt());
			trans.setAccount(account);
			accountDao.updateTransactionDetails(trans);
		} else {
			throw new Exception();
		}

	}

	public Customer getCustomerDetails(Customer cust) throws Exception {
		return accountDao.getCustomerDetails(cust);
	}

	public void saveBeneficiaries(Account acc, Beneficiaries ben)
			throws Exception {
		ben.setAccount(acc);
		accountDao.saveBeneficiaries(ben);

	}

	public boolean checkAccountExists(Beneficiaries ben) throws Exception {
		Account acc;
		System.out.println("Payee Acc Num:" + ben.getPayeeAccNum());
		if (ben.getPayeeAccNum() != 0) {
			acc = accountDao.checkAccountExists(ben.getPayeeAccNum());
		} else {
			return false;
		}
		if (acc.getAccId() != 0 && acc.getAccType().equalsIgnoreCase("Savings")) {
			return true;
		} else {
			return false;
		}
	}

	public List<Beneficiaries> getAllBeneficiaries(long accId) throws Exception {
		return accountDao.getAllBeneficiaries(accId);
	}


	public void updateFromAccount(Account account, long transAmt,Transaction trans) throws Exception {
		long savingsAccBalance = 0;
		savingsAccBalance = djUtil.getAccBalance(
				account.getAccBalance(), transAmt);
				account.setAccBalance(savingsAccBalance);
				account.setUpdatedDate(djUtil.getCurrentDate());
		accountDao.openSavingsAccount(account, true);
		Beneficiaries ben = trans.getBenificiary();
		System.out.println("Beneficiary Type"+ben.getBeneficiaryType());
		trans.setTransType("Debit");
		trans.setTransDate(djUtil.getCurrentDate());
		trans.setAccount(account);
		accountDao.updateTransactionDetails(trans);
		
	}

	public void updateToAccount(Transaction trans)
			throws Exception {
		System.out.println("trans.getBenificiary().getPayeeAccNum()==="+trans.getBenificiary().getPayeeAccNum());
		Account acc = accountDao.getAccountDetails(trans.getBenificiary().getCustomer().getId(), "SAVINGS");
		System.out.println("Payee acc =="+acc.getAccId());
		long savingsAccBalance = 0;
		savingsAccBalance = djUtil.addAccBalance(
				acc.getAccBalance(), trans.getTransAmt());
		acc.setAccBalance(savingsAccBalance);
		acc.setUpdatedDate(djUtil.getCurrentDate());
		accountDao.openSavingsAccount(acc, true);
		Beneficiaries ben = trans.getBenificiary();
		System.out.println("Beneficiary Type"+ben.getBeneficiaryType());
		trans.setTransType("Credit");
		trans.setTransDate(djUtil.getCurrentDate());
		trans.setAccount(acc);
		accountDao.updateTransactionDetails(trans);
	}

	public List<Transaction> loadAllTransactions(long accId) throws Exception {
		return accountDao.loadAllTransactions(accId);
	}

	public boolean isUserNameExists(String name) throws Exception {
		Customer cust = accountDao.isUserNameExists(name);
		if(null == cust) {
			return true;
		} else {
			return false;
		}
	}
	public Account checkAccountExists(long accId) throws Exception{
		return accountDao.checkAccountExists(accId);
		
	}

	public Customer getCustomerById(long custID) throws Exception {
		// TODO Auto-generated method stub
		return accountDao.getCustomerById(custID);
	}
}
