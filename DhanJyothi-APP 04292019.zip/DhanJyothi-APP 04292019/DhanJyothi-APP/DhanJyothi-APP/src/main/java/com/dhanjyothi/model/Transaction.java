package com.dhanjyothi.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "TRANSACTION_DETAILS")
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "TRANS_ID")
	private int id;
	@Column(name = "TRANS_TYPE")
	private String transType;
	@Column(name = "TRANS_AMT")
	private long transAmt;
	@Column(name = "TRANS_DATE")
	private Date transDate;
	@Column(name = "TRANS_DESC")
	private String remarks;
	@ManyToOne
	private Account account;
	@OneToOne
	private Beneficiaries benificiary;
	@Transient
	private List<Beneficiaries> beneficiaries;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public long getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(long transAmt) {
		this.transAmt = transAmt;
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Beneficiaries getBenificiary() {
		return benificiary;
	}

	public void setBenificiary(Beneficiaries benificiary) {
		this.benificiary = benificiary;
	}

	public List<Beneficiaries> getBeneficiaries() {
		return beneficiaries;
	}

	public void setBeneficiaries(List<Beneficiaries> beneficiaries) {
		this.beneficiaries = beneficiaries;
	}

	
	
	
	
	

}
