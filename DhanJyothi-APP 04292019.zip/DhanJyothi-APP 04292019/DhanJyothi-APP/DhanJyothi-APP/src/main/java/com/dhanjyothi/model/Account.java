package com.dhanjyothi.model;



import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="ACCOUNT_DETAILS")
public class Account {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ACCOUNT_NUMBER")
	private long accId;
	@Column(name="ACCOUNT_TYPE")
	private String accType;
	@Column(name="ACCOUNT_BALANCE")
	private long accBalance;
	@Column(name="TERM_TENURE")
	private int tenure;
	@Column(name="TERM_INTEREST")
	private float interest;
	@Column(name="TERM_MATURE")
	private Date matureDate;
	@Column(name="ACCOUNT_CREATED_DATE")
	private Date createdDate;
	@Column(name="ACCOUNT_UPDATED_DATE")
	private Date updatedDate;
	@Column(name="TERM_AMOUNT")
	private long termAmt;
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private Customer cust;
	public long getAccId() {
		return accId;
	}
	public void setAccId(long accId) {
		this.accId = accId;
	}
	
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public long getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(long accBalance) {
		this.accBalance = accBalance;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public float getInterest() {
		return interest;
	}
	public void setInterest(float interest) {
		this.interest = interest;
	}
	public Date getMatureDate() {
		return matureDate;
	}
	public void setMatureDate(Date matureDate) {
		this.matureDate = matureDate;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public long getTermAmt() {
		return termAmt;
	}
	public void setTermAmt(long termAmt) {
		this.termAmt = termAmt;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public Customer getCust() {
		return cust;
	}
	public void setCust(Customer cust) {
		this.cust = cust;
	}
	
	
	
	
	

}
