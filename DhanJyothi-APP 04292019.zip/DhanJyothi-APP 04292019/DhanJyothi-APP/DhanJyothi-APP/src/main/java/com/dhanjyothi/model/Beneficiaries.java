package com.dhanjyothi.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="BENEFICIARIES")
public class Beneficiaries {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="BENEFICIARY_ID")
	private long id;
	@Column(name="BENEFICIARY_NICK_NAME")
	private String payeeNickName;
	@Column(name="BENEFICIARY_NAME")
	private String payeeName;
	@Column(name="BENEFICIARY_ACC_NUM")
	private long payeeAccNum;
	@Column(name="BENEFICIARY_BANK_NAME")
	private String bankName;
	@Column(name="BENEFICIARY_IFSC_CODE")
	private long ifscCode;
	@Column(name="BENEFICIARY_TYPE")
	private String beneficiaryType;
	@ManyToOne
	private Account account;
	@ManyToOne
	private Customer customer;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getPayeeNickName() {
		return payeeNickName;
	}
	public void setPayeeNickName(String payeeNickName) {
		this.payeeNickName = payeeNickName;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public long getPayeeAccNum() {
		return payeeAccNum;
	}
	public void setPayeeAccNum(long payeeAccNum) {
		this.payeeAccNum = payeeAccNum;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public long getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(long ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBeneficiaryType() {
		return beneficiaryType;
	}
	public void setBeneficiaryType(String beneficiaryType) {
		this.beneficiaryType = beneficiaryType;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
}
