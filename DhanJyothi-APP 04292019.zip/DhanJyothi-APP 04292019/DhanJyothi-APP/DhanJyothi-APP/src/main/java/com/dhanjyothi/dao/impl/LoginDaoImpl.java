package com.dhanjyothi.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.dhanjyothi.dao.LoginDao;
import com.dhanjyothi.model.Customer;

@Repository("LoginDao")
public class LoginDaoImpl implements LoginDao {

	@Autowired
	//@Qualifier("hibernateTemplate")
	private HibernateTemplate hibernateTemplate;
	@SuppressWarnings("unused")
	public boolean validateCustomer(Customer customer) {
		boolean valid=false;
		System.out.println("Inside Validate Customer Dao");
		System.out.println(customer.getUserName()+"-"+customer.getPassword());
		//List<Customer> list=(List<Customer>) hibernateTemplate.find("from Customer where username=? and password=?", customer.getUsername(),customer.getPassword());
		List<Customer> list=hibernateTemplate.loadAll(Customer.class);
		System.out.println("List Size"+list.size());
		for(Customer c:list){
			System.out.println(customer.getUserName()+"-"+customer.getPassword());
			System.out.println(c.getUserName()+"-"+c.getPassword());
			if(customer.getUserName().equals(c.getUserName())&&customer.getPassword().equals(c.getPassword()))
			{
				valid=true;
				return valid;
			}
			else{
				valid=false;
			}
		}
		return valid;
		
		
		/*if (list!=null && list.size()>0) {
			 return true;
		} else {
			 return false;
		}*/
	}

	/*@Autowired
	@Qualifier("mySessionFactory")
	private SessionFactory sessionFactory;

	public boolean validateCustomer(Customer customer) {

		List<Customer> list = (List<Customer>) sessionFactory.getCurrentSession().createQuery("from Customer");
		if (list != null && list.size() > 0) {
			return true;
		} else {
			return false;
		}
	}*/

}
