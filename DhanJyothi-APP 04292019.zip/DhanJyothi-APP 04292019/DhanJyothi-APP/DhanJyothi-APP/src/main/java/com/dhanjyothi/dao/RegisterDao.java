package com.dhanjyothi.dao;

import java.util.List;

import com.dhanjyothi.model.Customer;

public interface RegisterDao {
	public void saveRegister(Customer customer);

	public List<Customer> getAllCustomers();
}
