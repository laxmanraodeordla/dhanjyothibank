package org.dhanjyothibank.pojo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "T_CUSTOMER")
public class Customer implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CUSTOMER_ID", nullable = false)
	private Long id;
	/*@NotEmpty
	@Size(min=5,max=100,message="Size.firstName.First Name Requires 5-100")
	*/@Column(name = "FIRST_NAME", nullable = false)
	private String firstName;
	/*@NotEmpty
	@Size(min=5,max=100)
	*/@Column(name = "LAST_NAME", nullable = false)
	private String lastName;
	/*@NotNull
	@DateTimeFormat(pattern="MM/dd/yyyy")
	*/@Column(name = "DATE_OF_BIRTH", nullable = false)
	private String dateOfBirth;
	/*@NotEmpty
	@Size(min=5,max=200)
	*/@Column(name = "ADDRESS_LINE1", nullable = false)
	private String addressLine1;
	/*@NotEmpty
	@Size(min=5,max=200)
	*/@Column(name = "ADDRESS_LINE2", nullable = false)
	private String addressLine2;
	/*@NotEmpty
	@Size(min=3,max=100)
	*/@Column(name = "CITY", nullable = false)
	private String city;
	/*@NotEmpty
	@Size(min=5,max=100)
	*/@Column(name = "STATE", nullable = false)
	private String state;
	/*@NotEmpty
	@Size(max=6)
	*/@Column(name = "PIN", nullable = false)
	private Integer pin;
	/*@NotEmpty
	@Size(max=10)
	*/@Column(name = "MOBILE_NUMBER", nullable = false)
	private Long mobileNumber;
	/*@NotEmpty
	@Size(min=10,max=50)
	*/@Column(name = "EMAIL", nullable = false)
	private String email;
	/*@NotEmpty
	@Size(max=12)
	*/@Column(name = "AADHAR", nullable = false)
	private String aadhar;
	/*@NotEmpty
	@Size(max=10)
	*/@Column(name = "PAN", nullable = false)
	private String pan;
	/*@NotEmpty
	@Size(min=8,max=15)
	*/@Column(name = "USER_NAME", nullable = false)
	private String userName;
	/*@NotEmpty
	@Size(min=8,max=15)
	*/@Column(name = "PASSWORD", nullable = false)
	private String password;
	@Transient
	@Column(name = "CONFIRM_PASSWORD", nullable = false)
	private String confirmPassword;

	/*@OneToOne(mappedBy="customer",cascade=CascadeType.ALL)
	private Account account =new Account();*/
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Integer getPin() {
		return pin;
	}

	public void setPin(Integer pin) {
		this.pin = pin;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + ", city=" + city
				+ ", state=" + state + ", pin=" + pin + ", mobileNumber=" + mobileNumber + ", email=" + email
				+ ", aadhar=" + aadhar + ", pan=" + pan + ", userName=" + userName + ", password=" + password
				+ ", confirmPassword=" + confirmPassword + "]";
	}

	

	/*public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}*/
	

}
