package org.dhanjyothibank.pojo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "T_ACCOUNT")
public class Account implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ACCOUNT_ID", nullable = false)
	private Long id;
	@Column(name = "ACCOUNT_NUMBER", nullable = false)
	private String accountNumber;
	@Column(name = "ACCOUNT_TYPE", nullable = false)
	private String accountType;
	@Column(name = "ACCOUNT_BALANCE", nullable = false)
	private Float accountBalance;
	@Column(name = "TENURE_RATE", nullable = false)
	private Float tenureRate;
	@Column(name = "INTREST_RATE", nullable = false)
	private Float intrestRate;
	@Column(name = "CREATE_DATE", nullable = false)
	private Date createDate;
	@Column(name = "MATURITY_DATE", nullable = false)
	private Date maturityDate;

	/*@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="CUSTOMER_ID")
	private Customer customer;
	*/
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(Float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Float getTenureRate() {
		return tenureRate;
	}

	public void setTenureRate(Float tenureRate) {
		this.tenureRate = tenureRate;
	}

	public Float getIntrestRate() {
		return intrestRate;
	}

	public void setIntrestRate(Float intrestRate) {
		this.intrestRate = intrestRate;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", accountNumber=" + accountNumber + ", accountType=" + accountType
				+ ", accountBalance=" + accountBalance + ", tenureRate=" + tenureRate + ", intrestRate=" + intrestRate
				+ ", createDate=" + createDate + ", maturityDate=" + maturityDate + "]";
	}

	/*public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}*/
	
	

}
