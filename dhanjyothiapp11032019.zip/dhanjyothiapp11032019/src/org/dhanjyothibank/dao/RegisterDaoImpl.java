package org.dhanjyothibank.dao;

import java.util.Base64;
import java.util.List;

import org.dhanjyothibank.pojo.Customer;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

@Repository("RegisterDao")
public class RegisterDaoImpl implements RegisterDao{
	
	@Autowired
	@Qualifier("hibernateTemplate")
	private HibernateTemplate hibernateTemplate;

	
	public void saveRegister(Customer customer) {
		customer.setPassword(Base64.getEncoder().encodeToString(customer.getPassword().getBytes()));
		hibernateTemplate.save(customer);
	}

	public List<Customer> getAllCustomers() {
		return hibernateTemplate.loadAll(Customer.class);
	}

	/*@Autowired
	@Qualifier("mySessionFactory")
	private SessionFactory sessionFactory;
	
	public void saveRegister(Customer customer) {
		sessionFactory.getCurrentSession().save(customer);
	}*/

}
