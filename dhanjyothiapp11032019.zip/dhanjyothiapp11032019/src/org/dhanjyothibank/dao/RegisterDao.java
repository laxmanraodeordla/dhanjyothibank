package org.dhanjyothibank.dao;

import java.util.List;

import org.dhanjyothibank.pojo.Customer;

public interface RegisterDao {
	public void saveRegister(Customer customer);
	public List<Customer> getAllCustomers();
}
