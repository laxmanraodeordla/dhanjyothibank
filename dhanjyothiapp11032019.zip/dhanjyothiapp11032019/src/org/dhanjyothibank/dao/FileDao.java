package org.dhanjyothibank.dao;

import java.util.List;

import org.dhanjyothibank.pojo.FileEntity;

public interface FileDao {
	public void saveFileUpload(FileEntity fileEntity);
	
	public List<FileEntity> viewAllFiles();
	
	public List<FileEntity> findByName(String fileName);
}
