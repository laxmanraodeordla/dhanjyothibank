package org.dhanjyothibank.dao;

import org.dhanjyothibank.pojo.Customer;

public interface LoginDao {
public boolean validateCustomer(Customer customer);
}
