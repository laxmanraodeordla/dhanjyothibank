package org.dhanjyothibank.service;

import java.util.Base64;

import org.dhanjyothibank.dao.LoginDaoImpl;
import org.dhanjyothibank.pojo.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("LoginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDaoImpl loginDaoImpl;

	public boolean validateCustomer(Customer customer) {
		System.out.println("Inside Validate Customer ");
		customer.setPassword(Base64.getEncoder().encodeToString(customer.getPassword().getBytes()));
		return loginDaoImpl.validateCustomer(customer);
	}

}
