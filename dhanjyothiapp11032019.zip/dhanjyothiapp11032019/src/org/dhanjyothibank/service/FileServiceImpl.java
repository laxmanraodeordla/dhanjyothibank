package org.dhanjyothibank.service;

import java.util.List;

import org.dhanjyothibank.dao.FileDaoImpl;
import org.dhanjyothibank.pojo.FileEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("FileService")
public class FileServiceImpl implements FileService {
	@Autowired
	public FileDaoImpl fileDaoImpl;

	@Transactional
	public void saveFileUpload(FileEntity fileEntity) {
		fileDaoImpl.saveFileUpload(fileEntity);
	}

	public List<FileEntity> viewAllFiles() {
		return fileDaoImpl.viewAllFiles();
	}

	public List<FileEntity> findByName(String fileName) {
		return fileDaoImpl.findByName(fileName);
	}

}
