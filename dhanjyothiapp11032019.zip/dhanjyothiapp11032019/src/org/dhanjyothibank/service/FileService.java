package org.dhanjyothibank.service;

import java.util.List;

import org.dhanjyothibank.pojo.FileEntity;

public interface FileService {
	public void saveFileUpload(FileEntity fileEntity);
	public List<FileEntity> viewAllFiles();
	public List<FileEntity> findByName(String fileName);
}
