package org.dhanjyothibank.service;

import org.dhanjyothibank.pojo.Customer;

public interface LoginService {
	public boolean validateCustomer(Customer customer);

}
