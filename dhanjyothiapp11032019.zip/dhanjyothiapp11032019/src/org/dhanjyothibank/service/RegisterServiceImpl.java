package org.dhanjyothibank.service;

import java.util.List;

import org.dhanjyothibank.dao.RegisterDaoImpl;
import org.dhanjyothibank.pojo.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("RegisterService")
public class RegisterServiceImpl implements RegisterService{

	@Autowired
	private RegisterDaoImpl registerDaoImpl;
	@Transactional
	public void saveRegister(Customer customer) {
		registerDaoImpl.saveRegister(customer);
	}
	public List<Customer> getAllCustomers() {
		return registerDaoImpl.getAllCustomers();
	}

}
