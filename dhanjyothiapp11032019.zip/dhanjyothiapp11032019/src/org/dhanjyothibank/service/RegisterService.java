package org.dhanjyothibank.service;

import java.util.List;

import org.dhanjyothibank.pojo.Customer;

public interface RegisterService {

	public void saveRegister(Customer customer);
	public List<Customer> getAllCustomers();
}
