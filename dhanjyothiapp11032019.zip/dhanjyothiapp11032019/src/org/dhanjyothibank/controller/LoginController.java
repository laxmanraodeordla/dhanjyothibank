package org.dhanjyothibank.controller;

import org.dhanjyothibank.pojo.Customer;
import org.dhanjyothibank.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView showRegister() {
		System.out.println("Hello Login form");
		ModelAndView mav = new ModelAndView();
		mav.addObject("cust", new Customer());
		mav.setViewName("login");
		return mav;
	}

	@RequestMapping(value = "/submit", method = RequestMethod.POST)
	public ModelAndView validateCustomer(@ModelAttribute("cust") Customer cust) {
		/*
		 * String user="laxman"; String pass="lucky";
		 * 
		 * System.out.println(cust); System.out.println("Form Submitted");
		 * if(user.equals(cust.getUsername())&&pass.equals(cust.getPassword()))
		 * return new ModelAndView("success"); else return new
		 * ModelAndView("error");
		 */
		System.out.println(cust);
		boolean flag=loginService.validateCustomer(cust);
		
		if(flag==true)
		{
			return new ModelAndView("login_success");
		}
		
		else{
			return new ModelAndView("error");
		}
	}

}
