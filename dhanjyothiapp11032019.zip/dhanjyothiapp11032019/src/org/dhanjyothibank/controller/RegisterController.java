package org.dhanjyothibank.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.dhanjyothibank.pojo.Customer;
import org.dhanjyothibank.service.RegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegisterController {
	/*
	@Autowired
	@Qualifier("customerValidator")
	private Validator validator;

	 @InitBinder
	   private void initBinder(WebDataBinder binder) {
	      binder.setValidator(validator);
	   }*/
	
	@Autowired
	private RegisterService registerService;

	@RequestMapping(value = "/signup", method = RequestMethod.GET)
	public ModelAndView showRegister() {
		System.out.println("Hello Register form");
		ModelAndView mav = new ModelAndView();
		mav.addObject("cust", new Customer());
		mav.setViewName("signup");
		return mav;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveRegister(@ModelAttribute("cust")  Customer cust,BindingResult bindingResult) {
		/*
		 * String user="laxman"; String pass="lucky";
		 * 
		 * System.out.println(cust); System.out.println("Form Submitted");
		 * if(user.equals(cust.getUsername())&&pass.equals(cust.getPassword()))
		 * return new ModelAndView("success"); else return new
		 * ModelAndView("error");
		 */
		System.out.println(cust);
		registerService.saveRegister(cust);
		return new ModelAndView("redirect:/getall");
	}

	@RequestMapping(value = "/getall", method = RequestMethod.GET)
	public ModelAndView getAllCustomers() {
		List<Customer> customers = registerService.getAllCustomers();
		System.out.println(customers);
		//return new ModelAndView("getall_customers", "customers", customers);
		ModelAndView mav=new ModelAndView();
		mav.addObject("customers", customers);
		mav.setViewName("getall_customers");
		return mav;
}

}
